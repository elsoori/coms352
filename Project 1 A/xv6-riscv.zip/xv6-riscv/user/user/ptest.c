// They are supposed to be different. At the initial pcount, the child process has not begun.
// At the second instance of pcount, child process has been created,so the process count is increased. 


#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int
main(void)
{
    int count = pcount();
    printf("Process count: %d\n", count);

    if(fork() > 0)
    {
        sleep(5);  // Let child exit before parent.
        count = pcount();
        printf("Process count after sleep(): %d\n", count);
    }
    exit(0);
}


