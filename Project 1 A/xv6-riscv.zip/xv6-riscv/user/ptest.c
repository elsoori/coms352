//Eranda Sooriyarachchi 

//They are supposed to be different. At the intitial pcount, the child process has not begun. At the second instance of pcount, child process has been 
//created, so the process count is increased. So process count goes from 3 to 4.

#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int main(void)
{
  int count = pcount();
  printf("Process count before fork(): %d\n", count);
  if(fork() > 0)
  {
    sleep(5);
    count = pcount();
    printf("Process count after sleep: %d\n", count);
  }
  exit(0);
}

